package models

type Player struct{
	
}