package main

import "fmt"

func main() {
	fmt.Println("Starting server on port 4000.....")
}